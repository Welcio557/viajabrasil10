import React from 'react';

function App() {
  return (
    <div className="fixed inset-0 bg-[#0CAEAB] overflow-hidden">
      <div className="container mx-auto px-4 h-full flex flex-col items-center">
        <div className="w-full max-w-[300px] mt-4">
          <h1 className="text-white font-bold text-2xl md:text-2x1 text-center mb-8">
            Seu Cartãozinho Pronto <br></br>Sem Complicações
          </h1>
          
          <div className="relative w-full">
            <div className="relative" style={{ paddingTop: '177.78%' }}>
              <wistia-player
                media-id="0jrhe58hxt"
                className="absolute top-0 left-0 w-full h-full"
              ></wistia-player>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;